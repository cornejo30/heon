const nodemailer = require('nodemailer');

// Configuración del transportador de Nodemailer
const transporter = nodemailer.createTransport({
    service: 'Gmail', // Puedes usar otros servicios de correo como Yahoo, Outlook, etc.
    auth: {
        user: 'tatozf586@gmail.com',
        pass: 'ovvg qwqb sesj bzlb'
    }
});

// Función para enviar correos de confirmación
function sendConfirmationEmail(user, token) {
    const url = `https://localhost:3000/confirmation/${token}`;
    transporter.sendMail({
        from: '"HEON" <tatozf586@gmail.com>',
        to: user.email,
        subject: 'Confirmación de cuenta',
        html: `Por favor, haz clic en el siguiente enlace para confirmar tu cuenta: <a href="${url}">${url}</a>`
    });
}

// Función para enviar correos de recuperación de contraseña
function sendPasswordResetEmail(user, token) {
    const url = `https://localhost:3000/reset/${token}`;
    transporter.sendMail({
        from: '"HEON" <tatozf586@gmail.com>',
        to: user.email,
        subject: 'Restablecimiento de contraseña',
        html: `Por favor, haz clic en el siguiente enlace para restablecer tu contraseña: <a href="${url}">${url}</a>`
    });
}

module.exports = {
    sendConfirmationEmail,
    sendPasswordResetEmail
};
