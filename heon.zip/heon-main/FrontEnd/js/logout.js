document.getElementById('logoutButton').addEventListener('click', async () => {
    try {
        const response = await fetch('/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (response.ok) {
            // Redirigir a la página de inicio de sesión o página principal
            window.location.href = '/login';
        } else {
            // Mostrar mensaje de error
            const result = await response.json();
            alert(result.message || 'Error al cerrar sesión. Inténtalo de nuevo.');
        }
    } catch (error) {
        alert('Error al cerrar sesión. Inténtalo de nuevo.');
    }
});
