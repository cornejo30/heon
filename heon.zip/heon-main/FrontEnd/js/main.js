document.addEventListener('DOMContentLoaded', async () => {
    const productPreviewSection = document.getElementById('productPreview');

    try {
        const response = await fetch('/bestsellers');
        const products = await response.json();

        products.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.classList.add('product');
            productDiv.innerHTML = `
                <img src="${product.imageUrl}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>${product.price}</p>
                <button>Agregar al Carrito</button>
            `;
            productPreviewSection.appendChild(productDiv);
        });
    } catch (error) {
        console.error('Error al cargar los productos:', error);
    }
});
