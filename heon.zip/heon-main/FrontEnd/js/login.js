document.addEventListener('DOMContentLoaded', () => {
    fetch('/csrf-token', {
        method: 'GET',
        credentials: 'include'
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('csrfToken').value = data.csrfToken;
    })
    .catch(error => console.error('Error al obtener el token CSRF:', error));
});

document.getElementById('loginForm').addEventListener('submit', async function(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const csrfToken = document.getElementById('csrfToken').value;

    const response = await fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'CSRF-Token': csrfToken
        },
        body: JSON.stringify({ email, password })
    });

    const data = await response.json();
    alert(data.message);

    if (response.ok) {
        window.location.href = '/dashboard'; // Redirigir a una página de dashboard después de iniciar sesión
    }
});
