document.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');
    const userId = '_id'; // Reemplaza con la forma correcta de obtener el ID del usuario

    if (productId) {
        try {
            const response = await fetch(`/api/products/${productId}`);
            const product = await response.json();

            document.getElementById('productImage').src = product.imageUrl;
            document.getElementById('productName').textContent = product.name;
            document.getElementById('productDescription').textContent = product.description;
            document.getElementById('productPrice').textContent = `$${product.price.toFixed(2)}`;

            document.querySelectorAll('.size-btn').forEach(button => {
                button.addEventListener('click', () => {
                    document.querySelectorAll('.size-btn').forEach(btn => btn.classList.remove('selected'));
                    button.classList.add('selected');
                });
            });

            document.getElementById('addToCart').addEventListener('click', async () => {
                const selectedSize = document.querySelector('.size-btn.selected');
                if (selectedSize) {
                    await addToCart(productId, selectedSize.value);
                } else {
                    alert('Por favor selecciona una talla.');
                }
            });

            document.getElementById('addToFavorites').addEventListener('click', async () => {
                await addToFavorites(productId);
            });
        } catch (error) {
            console.error('Error al cargar los detalles del producto:', error);
        }
    } else {
        console.error('No se encontró el ID del producto en la URL.');
    }
});

async function addToCart(productId, size) {
    const userId = '_id'; // Reemplaza con la forma correcta de obtener el ID del usuario

    const response = await fetch(`/api/cart/${userId}/add`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ productId, size })
    });

    if (response.ok) {
        alert('Producto añadido al carrito.');
    } else {
        alert('Hubo un problema al agregar el producto al carrito.');
    }
}

async function addToFavorites(productId) {
    const userId = '_id'; // Reemplaza con la forma correcta de obtener el ID del usuario

    const response = await fetch(`/api/favorites/${userId}/add`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ productId })
    });

    if (response.ok) {
        alert('Producto añadido a favoritos.');
    } else {
        alert('Hubo un problema al agregar el producto a favoritos.');
    }
}
