document.addEventListener('DOMContentLoaded', async () => {
    const productList = document.getElementById('productList');
    
    try {
        const response = await fetch('/api/products');
        const products = await response.json();

        products.forEach(product => {
            const listItem = document.createElement('li');
            const link = document.createElement('a');
            link.href = `/product.html?id=${product._id}`;
            link.textContent = product.name;
            listItem.appendChild(link);
            productList.appendChild(listItem);
        });
    } catch (err) {
        console.error('Error al obtener productos:', err);
    }
});
