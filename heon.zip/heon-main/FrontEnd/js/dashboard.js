document.addEventListener('DOMContentLoaded', async () => {
    const productContainer = document.getElementById('productContainer');

    try {
        const response = await fetch('/api/products');
        const products = await response.json();

        products.forEach(product => {
            const productCard = document.createElement('div');
            productCard.classList.add('product-card');

            productCard.innerHTML = `
                <a href="/product.html?id=${product._id}" class="product-link">
                    <img src="${product.imageUrl}" alt="${product.name}">
                    <h2>${product.name}</h2>
                    <h3>${product.description}</h3>
                    <p>$${product.price.toFixed(2)}</p>
                </a>
            `;

            productContainer.appendChild(productCard);
        });
    } catch (error) {
        console.error('Error al cargar los productos:', error);
    }
});
