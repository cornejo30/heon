document.addEventListener('DOMContentLoaded', () => {


    const registerButton = document.getElementById('registerButton');
    const termsCheckbox = document.getElementById('terms');
    const openPrivacyLink = document.getElementById('openPrivacy');

    // Deshabilitar el botón de registro inicialmente
    registerButton.disabled = true;
    registerButton.classList.add('disabled');

    // Habilitar/deshabilitar el botón de registro según el estado del checkbox
    termsCheckbox.addEventListener('change', () => {
        registerButton.disabled = !termsCheckbox.checked;
        if (termsCheckbox.checked) {
            registerButton.classList.remove('disabled');
        } else {
            registerButton.classList.add('disabled');
        }
    });

    // Abrir la política de privacidad en una ventana emergente
    openPrivacyLink.addEventListener('click', (event) => {
        event.preventDefault();
        window.open('/privacity', 'Privacidad', 'width=400,height=250');
    });

    document.getElementById('registerForm').addEventListener('submit', async function(event) {
        event.preventDefault();
        
        const username = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        try {
            const response = await fetch('/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'CSRF-Token': csrfToken
                },
                body: JSON.stringify({ username, email, password })
            });

            const data = await response.json();
            alert(data.message);

            if (response.ok) {
                window.location.href = '/login'; // Redirigir a la página de inicio de sesión después de registrarse
            }
        } catch (error) {
            console.error('Error al analizar JSON:', error);
            alert('Ocurrió un error en el servidor. Por favor, inténtalo de nuevo.');
        }
    });
});
