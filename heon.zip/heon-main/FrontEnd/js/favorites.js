document.addEventListener('DOMContentLoaded', async () => {
    const userId = 'usuario_id_aqui'; // Reemplaza con la forma correcta de obtener el ID del usuario
    const favoriteProductsContainer = document.getElementById('favorite-products');

    async function loadFavorites() {
        const response = await fetch(`/api/favorites/${userId}`);
        const favorites = await response.json();

        favoriteProductsContainer.innerHTML = '';
        favorites.products.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.innerHTML = `
                <h2>${product.name}</h2>
                <button class="remove-button" data-id="${product._id}">Eliminar</button>
            `;
            favoriteProductsContainer.appendChild(productDiv);
        });

        const removeButtons = document.querySelectorAll('.remove-button');
        removeButtons.forEach(button => {
            button.addEventListener('click', async (e) => {
                const productId = e.target.getAttribute('data-id');
                await fetch(`/api/favorites/${userId}/remove`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ productId })
                });
                loadFavorites();
            });
        });
    }

    loadFavorites();
});
