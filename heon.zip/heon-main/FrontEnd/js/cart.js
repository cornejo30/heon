let cart = [];
let totalPrice = 0;

function addToCart(productName, productPrice) {
    // Añadir el producto al carrito
    cart.push({ name: productName, price: productPrice });
    
    // Actualizar el total
    totalPrice += productPrice;
    
    // Actualizar la visualización del carrito
    updateCartDisplay();
}

function updateCartDisplay() {
    const cartItems = document.getElementById('cart-items');
    const totalElement = document.getElementById('total-price');
    
    // Limpiar la lista de artículos del carrito
    cartItems.innerHTML = '';
    
    // Añadir cada artículo del carrito a la lista
    cart.forEach(item => {
        const listItem = document.createElement('li');
        listItem.textContent = `${item.name} - $${item.price}`;
        cartItems.appendChild(listItem);
    });
    
    // Mostrar el precio total
    totalElement.textContent = `Total: $${totalPrice}`;
}
