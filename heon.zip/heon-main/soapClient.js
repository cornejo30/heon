const soap = require('soap');

const url = 'URL_DEL_SERVICIO_SOAP?wsdl'; // Reemplaza con la URL de tu servicio SOAP

async function getConversionRate() {
    return new Promise((resolve, reject) => {
        soap.createClient(url, (err, client) => {
            if (err) {
                return reject(err);
            }

            client.ConversionRate({}, (err, result) => { // Reemplaza 'ConversionRate' y los parámetros con los correctos
                if (err) {
                    return reject(err);
                }
                resolve(result.ConversionRateResult); // Ajusta según la estructura del resultado
            });
        });
    });
}

module.exports = { getConversionRate };
