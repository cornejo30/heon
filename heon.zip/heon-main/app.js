const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcrypt');
const fs = require('fs');
const https = require('https');
const path = require('path');
const csrf = require('csurf');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const crypto = require('crypto');
const User = require('./models/User');
const Product = require('./models/Product');
const { getConversionRate } = require('./soapClient');
const { sendConfirmationEmail, sendPasswordResetEmail } = require('./services/mailer');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(cookieParser());
app.use(session({
    secret: 'your_secret_key', // Cambia 'your_secret_key' por una clave segura
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // Cambia a true si usas HTTPS
}));

const csrfProtection = csrf({ cookie: true });

app.use('/css', express.static(path.join(__dirname, 'FrontEnd', 'css')));
app.use('/js', express.static(path.join(__dirname, 'FrontEnd', 'js')));
app.use('/images', express.static(path.join(__dirname, 'FrontEnd', 'images')));

function isAuthenticated(req, res, next) {
    if (req.session.userId) {
        return next();
    }
    res.status(401).json({ message: 'No autorizado.' });
}

module.exports = { isAuthenticated };


// Función para validar contraseñas
function validatePassword(password) {
    const minLength = /.{8,}/;
    const hasUppercase = /[A-Z]/;
    const hasLowercase = /[a-z]/;
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/;
    const noConsecutiveNumbers = /^(?!.*(\d)\1)/;
    const noConsecutiveLetters = /^(?!.*([a-zA-Z])\1)/;

    return minLength.test(password) &&
           hasUppercase.test(password) &&
           hasLowercase.test(password) &&
           hasSpecialChar.test(password) &&
           noConsecutiveNumbers.test(password) &&
           noConsecutiveLetters.test(password);
}

// Ruta para registrar un nuevo usuario
app.post('/register', async (req, res) => {
    const { username, email, password } = req.body;

    if (!validatePassword(password)) {
        return res.status(400).json({ message: 'La contraseña no cumple con los requisitos.' });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const confirmationToken = crypto.randomBytes(32).toString('hex');
        const user = new User({ username, email, password: hashedPassword, confirmationToken });

        await user.save();
        sendConfirmationEmail(user, confirmationToken);
        res.status(201).json({ message: 'Usuario registrado con éxito. Por favor, confirma tu correo electrónico.' });
    } catch (err) {
        console.error('Error al registrar usuario:', err);
        res.status(500).json({ message: 'Error al registrar usuario.' });
    }
});

// Ruta para confirmar la cuenta
app.get('/confirm/:token', async (req, res) => {
    try {
        const user = await User.findOne({ confirmationToken: req.params.token });

        if (!user) {
            return res.status(400).json({ message: 'Token de confirmación no válido.' });
        }

        user.isConfirmed = true;
        user.confirmationToken = undefined;
        await user.save();

        res.sendFile(path.join(__dirname, 'FrontEnd', 'confirmation.html'));
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error al confirmar cuenta.' });
    }
});

// Ruta para solicitar el restablecimiento de contraseña
app.post('/forgot-password', async (req, res) => {
    const { email } = req.body;

    try {
        const user = await User.findOne({ email });

        if (!user) {
            return res.status(400).json({ message: 'Usuario no encontrado.' });
        }

        const resetToken = crypto.randomBytes(32).toString('hex');
        user.resetToken = resetToken;
        user.resetTokenExpiration = Date.now() + 3600000; // 1 hora
        await user.save();

        sendPasswordResetEmail(user, resetToken);
        res.status(200).json({ message: 'Correo de restablecimiento de contraseña enviado.' });
    } catch (err) {
        console.error('Error al enviar correo de restablecimiento de contraseña:', err);
        res.status(500).json({ message: 'Error al enviar correo de restablecimiento de contraseña.' });
    }
});

app.get('/forgot-password', (req, res) => {
    res.sendFile(path.join(__dirname, 'FrontEnd', 'forgot-password.html'));
});

// Ruta para restablecer la contraseña
app.post('/reset/:token', async (req, res) => {
    const { password } = req.body;

    try {
        const user = await User.findOne({ resetToken: req.params.token, resetTokenExpiration: { $gt: Date.now() } });

        if (!user) {
            return res.status(400).json({ message: 'Token de restablecimiento no válido o expirado.' });
        }

        if (!validatePassword(password)) {
            return res.status(400).json({ message: 'La contraseña no cumple con los requisitos.' });
        }

        user.password = await bcrypt.hash(password, 10);
        user.resetToken = undefined;
        user.resetTokenExpiration = undefined;
        await user.save();

        res.status(200).json({ message: 'Contraseña restablecida con éxito.' });
    } catch (err) {
        console.error('Error al restablecer la contraseña:', err);
        res.status(500).json({ message: 'Error al restablecer la contraseña.' });
    }
});

// Ruta para iniciar sesión
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findOne({ email });

        if (!user) {
            return res.status(400).json({ message: 'Usuario no encontrado.' });
        }

        if (!user.isConfirmed) {
            return res.status(400).json({ message: 'Por favor, confirma tu cuenta primero.' });
        }

        const isPasswordValid = await bcrypt.compare(password, user.password);

        if (!isPasswordValid) {
            return res.status(400).json({ message: 'Contraseña incorrecta.' });
        }

        req.session.userId = user._id;
        res.status(200).json({ message: 'Inicio de sesión exitoso.' });
    } catch (err) {
        console.error('Error al iniciar sesión:', err);
        res.status(500).json({ message: 'Error al iniciar sesión.' });
    }
});

// Ruta para cerrar sesión
app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            console.error('Error al cerrar sesión:', err);
            return res.status(500).json({ message: 'Error al cerrar sesión.' });
        }
        res.clearCookie('connect.sid');
        res.status(200).json({ message: 'Sesión cerrada exitosamente.' });
    });
});

// Middleware para verificar si el usuario está autenticado
function isAuthenticated(req, res, next) {
    if (req.session.userId) {
        return next();
    }
    res.status(401).json({ message: 'No autorizado.' });
}

// Rutas para servir archivos HTML
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'FrontEnd', 'login.html'));
});

app.get('/register', csrfProtection, (req, res) => {
    res.sendFile(path.join(__dirname, 'FrontEnd', 'registro.html'));
});

app.get('/dashboard', csrfProtection, isAuthenticated, (req, res) => {
    res.sendFile(path.join(__dirname, 'FrontEnd', 'dashboard.html'));
});

app.get('/profile', csrfProtection, isAuthenticated, (req, res) => {
    res.sendFile(path.join(__dirname, 'FrontEnd', 'profile.html'));
});

app.get('/bestsellers', csrfProtection, async (req, res) => {
    try {
        const bestSellers = await Product.find({ isBestSeller: true });
        res.json(bestSellers);
    } catch (err) {
        console.error('Error al obtener los productos más vendidos:', err);
        res.status(500).json({ message: 'Error al obtener los productos más vendidos.' });
    }
});

app.get('/privacity', (req, res) => {
    res.sendFile(path.join(__dirname, 'FrontEnd', 'privacity.html'));
});

// Rutas para productos
app.get('/api/products', async (req, res) => {
    try {
        const products = await Product.find();
        res.json(products);
    } catch (err) {
        console.error('Error al obtener productos:', err);
        res.status(500).json({ message: 'Error al obtener productos.' });
    }
});

app.get('/dollar-rate', async (req, res) => {
    try {
        const rate = await getConversionRate();
        res.json({ rate });
    } catch (err) {
        console.error('Error al obtener la tasa de conversión del dólar:', err);
        res.status(500).json({ message: 'Error al obtener la tasa de conversión del dólar.' });
    }
});

app.get('/products', (req, res) => {
    res.sendFile(path.join(__dirname, 'FrontEnd', 'products.html'));
});

app.get('/api/products/:id', async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        res.json(product);
    } catch (err) {
        console.error('Error al obtener el producto:', err);
        res.status(500).json({ message: 'Error al obtener el producto.' });
    }
});

app.get('/product.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'FrontEnd', 'product.html'));
});

// Ruta para manejar errores 404
app.use((req, res, next) => {
    res.status(404).json({ message: 'Recurso no encontrado.' });
});

// Ruta para manejar errores 500
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Error del servidor.' });
});

// Conexión a MongoDB y configuración del servidor HTTPS
mongoose.connect('mongodb://localhost:27017/heon', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        const sslOptions = {
            key: fs.readFileSync('./key.pem'),
            cert: fs.readFileSync('./cert.pem')
        };

        https.createServer(sslOptions, app).listen(3000, () => {
            console.log('Servidor HTTPS iniciado en https://localhost:3000');
        });
    })
    .catch(err => console.error('Error al conectar a MongoDB:', err));
